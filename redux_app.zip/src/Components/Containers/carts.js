import React from 'react';
import { decreaseQuantity, increaseQuantity, deleteFromCart } from "../../reduxStore/cartSlice";
import { useDispatch, useSelector } from "react-redux";
import { cartTotalPriceSelector } from '../../reduxStore/selector';
import { toggle } from '../../reduxStore/toggleSlice';

export default function Carts() {
    const dispatch = useDispatch();
    const cartList = useSelector((state) => state.cart);
    const totalPrice = useSelector(cartTotalPriceSelector);
    const cartVisible = useSelector((state) => state.toggleR.cartDrawerVisible);
    console.log(cartVisible)
    return (
        <>
        {cartVisible && <div className='cart_section'>

            <div className='itemsList'>
                {cartList?.map((item) => (

                    <div className='itemsCard' key={item.id}>
                        <div>
                            <img src={item.imageUrl} />
                        </div>
                        <div>{item.title}</div>
                        <div>{item.description}</div>
                        <div>{item.price}Rs/-</div>
                        <div>
                            <button onClick={() => { dispatch(decreaseQuantity(item.id)) }}>-</button>
                            <span>{item.quantity}</span>
                            <button onClick={() => { dispatch(increaseQuantity(item.id)) }}>+</button>
                        </div>
                        <div>
                            <button onClick={() => { dispatch(deleteFromCart(item)) }}>Delete</button>
                        </div>
                    </div>))}

                <div>Total Quantity: {totalPrice}</div>



            </div>
        </div>}

        {cartVisible &&<div className='mask_container' onClick={()=>dispatch(toggle())}>
        </div>}
        </>
    )
}
