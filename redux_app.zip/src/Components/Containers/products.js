import React from 'react';
import { addToCart } from '../../reduxStore/cartSlice';
import { useDispatch, useSelector } from "react-redux";

export default function Products() {
    const dispatch = useDispatch();
    const itemsList = useSelector((state) => state.products);
    return (
        <>
            <div>products list</div>
            <div className='itemsList'>
                {itemsList?.list?.map((item) => (

                    <div className='itemsCard' key={item.id}>
                        <div>
                            <img src={item.imageUrl} />
                        </div>
                        <div>{item.title}</div>
                        <div>{item.description}</div>
                        <div>{item.price}Rs/-</div>
                        <button onClick={() => { dispatch(addToCart(item)); }}>Add to Cart</button>
                    </div>))}

            </div>
        </>
    )
}
