import { createSlice} from "@reduxjs/toolkit";

const initialState ={
    cartDrawerVisible: false
}

const toggleSlice = createSlice({
    name: "toggle",
    initialState,
    reducers:{
        toggle(state){
           state.cartDrawerVisible = !state.cartDrawerVisible;
        }
    }
})


export const {toggle} = toggleSlice.actions;

const toggleReducer = toggleSlice.reducer;

export default toggleReducer;