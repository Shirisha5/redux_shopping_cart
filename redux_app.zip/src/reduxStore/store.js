import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "./cartSlice";
import productReducer from "./productSlice";
import toggleReducer from "./toggleSlice";





const store = configureStore({
    reducer: {
        products: productReducer,
        cart: cartReducer,
        toggleR: toggleReducer
    }
})

export default store;

