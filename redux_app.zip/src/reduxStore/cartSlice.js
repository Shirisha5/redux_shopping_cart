import { createSlice } from "@reduxjs/toolkit";

const initialState = [];

const cartSlice = createSlice({
    name: "cart",
    initialState,
    reducers: {
        addToCart(state, { payload }) {
            console.log(state, payload)
            const { id } = payload;
            const find = state.find((item) => item.id === id);
            if (find) {
                return state.map((item) =>
                    item.id === id ? { ...item, quantity: item.quantity + 1, totalprice: item.price*item.quantity} : item);
            } else {
                state.push({
                    ...payload,
                    quantity: 1,
                    totalprice: payload.price
                })
            }
        },
        decreaseQuantity(state, { payload }) {
            console.log(payload)
            return state.map((item) =>
                (item.id === payload && item.quantity > 1)
                    ? {
                        ...item,
                        quantity: item.quantity - 1,
                        totalprice: item.price * item.quantity
                    }
                    : item
            );
        },
        increaseQuantity(state, { payload }) {
            console.log(payload)
            return state.map((item) =>
                item.id === payload
                    ? {
                        ...item,
                        quantity: item.quantity + 1,
                        totalprice: item.price * item.quantity
                    }
                    : item
            );
        },
        deleteFromCart(state, { payload }) {
            console.log(payload)
            const { id } = payload;
            return state.filter((item) => item.id !== id);
        },
    }
})


export const { addToCart, increaseQuantity, decreaseQuantity, deleteFromCart } = cartSlice.actions;

const cartReducer = cartSlice.reducer;
export default cartReducer;
