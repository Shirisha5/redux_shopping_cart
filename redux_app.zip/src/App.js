// import './App.css';
import Navbar from './Components/Nav/Navbar';
import Products from './Components/Containers/products';
import Carts from './Components/Containers/carts';
import React, { useEffect, useState, useRef } from "react";
import "./pokemon.css";

function App() {
  const [pokemons, setPokemons] = useState([]);
  const [page, setPage] = useState(10);
  const [loading, setLoading] = useState(false);
  const pageEnd = useRef(null)



  const initialData = async () => {
    console.log("initialData")
    await fetch(`https://pokeapi.co/api/v2/pokemon?limit=500`)
      .then(response => response.json())
      .then(data =>
        setPokemons(data.results));
    setLoading(true);
  }

  useEffect(() => {
    initialData()
  }, [])
  useEffect(() => {

    if (loading) {
      const observer = new IntersectionObserver(entries => {
        console.log(entries[0].isIntersecting)
        if (entries[0].isIntersecting) {
          loadMore()
        }
      }, { threshold: 1 });
      observer.observe(pageEnd.current)
    }


  }, [loading])


  const loadMore = () => {


    setPage(prev => prev + 10)
    setLoading(true)

  }
 
  return (
    // <div className="App">

    //   <Navbar />

    //   <div className='product_list'>
    //     <Products />
    //   </div>




    //   <Carts />



    // </div>
    <div className='pokemon_app'>
      <div className="pokemon_wrapper">

        <div className="pokemon_card_list">
          {pokemons?.slice(0, page).map((poke) => (

            <div className="pokemon_card" key={poke.name} >
              <div className="pokemon_card_img">
                <img src={`https://img.pokemondb.net/artwork/large/${poke.name}.jpg`} loading="lazy" />
              </div>
              <div className="pokemon_card_title">{poke.name}</div>
            </div>
          ))}
        </div>

        <p className="pokemon_loading_text">loading...</p>
        <div className='load_more_btn' ref={pageEnd}>
          {/* <button onClick={() => loadMore()}>Load More</button> */}
        </div>
      </div>
    </div>
  );
}

export default App;
